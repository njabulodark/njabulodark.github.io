import React from 'react';

const EventsPage: React.FC = () => {
  return (
    <div className="bg-white min-h-screen">
      {/* Page Title */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-6 sm:px-8 max-w-6xl">
          <h1 className="text-4xl md:text-5xl font-bold text-[#26262c] mb-4">Events</h1>
          <div className="w-20 h-1 bg-[#4747d7]"></div>
        </div>
      </section>

      {/* Event 1: Matric Dance (Nov 2024) */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-6 sm:px-8 max-w-6xl">
          <h6 className="text-lg font-medium text-[#6e71e4] mb-2">November 23/ 2024 / 15:00 pm</h6>
          <h3 className="text-2xl md:text-3xl font-bold text-[#2107c8] mb-8" style={{ textShadow: '1px 1px 2px rgba(0,0,0,0.1)' }}>
            "Class of 2024 MATRIC DANCE: A night to Remember"
          </h3>
          
          <div className="mb-8">
            <div className="bg-gray-200 border-2 border-dashed rounded-xl w-full h-96 flex items-center justify-center mb-6">
              <span className="text-gray-500">Matric Dance Slideshow</span>
            </div>
            
            <p className="text-[#76767f] italic font-bold mb-4">
              What a night to remember!!!!!
            </p>
            <p className="text-[#76767f] mb-6">
              The Brently Lodge and Lifestyle Centre in Durban was transformed into a magical wonderland for the Class of 2024 Matric Dance, marking a joyous celebration of the end of their journey as Sacred Heart scholars. The night was filled with elegance, celebration, and the promise of bright futures ahead.
            </p>
          </div>
          
          <h4 className="text-xl font-bold text-[#26262c] mb-6">Event Gallery</h4>
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-4">
            {[...Array(10)].map((_, index) => (
              <div key={index} className="bg-gray-200 border-2 border-dashed rounded-lg w-full h-48 flex items-center justify-center">
                <span className="text-gray-500 text-xs">Matric Dance {index + 1}</span>
              </div>
            ))}
          </div>
        </div>
      </section>

      <div className="border-t border-gray-200 mx-6 sm:mx-8 max-w-6xl"></div>

      {/* Event 2: Business Lunch (Oct 2024) */}
      <section className="py-16 bg-[#f6f7fd]">
        <div className="container mx-auto px-6 sm:px-8 max-w-6xl">
          <h6 className="text-lg font-medium text-[#6e71e4] mb-2">0ctober 08 / 2024 / 10:00 AM</h6>
          <h3 className="text-2xl md:text-3xl font-bold text-[#2107c8] mb-8" style={{ textShadow: '1px 1px 2px rgba(0,0,0,0.1)' }}>
            Sacred Heart Business Lunch
          </h3>
          
          <div className="mb-8">
            <div className="bg-gray-200 border-2 border-dashed rounded-xl w-full h-96 flex items-center justify-center mb-6">
              <span className="text-gray-500">Business Lunch Slideshow</span>
            </div>
            
            <p className="text-[#76767f] mb-6">
              Our exclusive Business Lunch brought together top companies and industry leaders to explore potential partnerships. We highlighted ongoing projects including hostel renovations, classroom upgrades, and sports facility enhancements, inviting businesses to contribute to our students' future.
            </p>
          </div>
          
          <h4 className="text-xl font-bold text-[#26262c] mb-6">Event Gallery</h4>
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-3 gap-4">
            {[...Array(9)].map((_, index) => (
              <div key={index} className="bg-gray-200 border-2 border-dashed rounded-lg w-full h-48 flex items-center justify-center">
                <span className="text-gray-500 text-xs">Business Lunch {index + 1}</span>
              </div>
            ))}
          </div>
        </div>
      </section>

      <div className="border-t border-gray-200 mx-6 sm:mx-8 max-w-6xl"></div>

      {/* Event 3: Gala Dinner (Sep 2024) */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-6 sm:px-8 max-w-6xl">
          <h6 className="text-lg font-medium text-[#6e71e4] mb-2">September 19 / 2024 / 17:00pm</h6>
          <h3 className="text-2xl md:text-3xl font-bold text-[#2107c8] mb-8" style={{ textShadow: '1px 1px 2px rgba(0,0,0,0.1)' }}>
            GALA DINNER
          </h3>
          
          <div className="mb-8">
            <div className="bg-gray-200 border-2 border-dashed rounded-xl w-full h-96 flex items-center justify-center mb-6">
              <span className="text-gray-500">Gala Dinner Slideshow</span>
            </div>
            
            <p className="text-[#76767f] mb-6">
              On the 19th of September 2024, Sacred Heart Secondary School hosted its prestigious Annual Gala Dinner. Distinguished guests from the Department of Education joined us to celebrate academic excellence. The evening featured awards for our top students and a gourmet feast prepared by our esteemed catering partners.
            </p>
          </div>
          
          <h4 className="text-xl font-bold text-[#26262c] mb-6">Event Gallery</h4>
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-4">
            {[...Array(12)].map((_, index) => (
              <div key={index} className="bg-gray-200 border-2 border-dashed rounded-lg w-full h-48 flex items-center justify-center">
                <span className="text-gray-500 text-xs">Gala Dinner 2024 {index + 1}</span>
              </div>
            ))}
          </div>
        </div>
      </section>

      <div className="border-t border-gray-200 mx-6 sm:mx-8 max-w-6xl"></div>

      {/* Event 4: Gala Dinner (Sep 2023 - Previous Year) */}
      <section className="py-16 bg-[#f6f7fd]">
        <div className="container mx-auto px-6 sm:px-8 max-w-6xl">
          <h6 className="text-lg font-medium text-[#6e71e4] mb-2">September 30 / 2023 / 14:00 PM</h6>
          <h3 className="text-2xl md:text-3xl font-bold text-[#2107c8] mb-8" style={{ textShadow: '1px 1px 2px rgba(0,0,0,0.1)' }}>
            GALA DINNER
          </h3>
          
          <div className="mb-8">
            <div className="bg-gray-200 border-2 border-dashed rounded-xl w-full h-96 flex items-center justify-center mb-6">
              <span className="text-gray-500">Gala Dinner 2023 IMG_9557-scaled.jpg</span>
            </div>
            
            <p className="text-[#76767f] mb-6">
              Sacred Heart Secondary School hosted its prestigious Annual Gala Dinner in partnership with Sumptuous Caterers. The event was graced by notable alumni including Prof M Mkhize from UKZN and Dr Mahaye from the Department of Education, celebrating our students' achievements and the school's legacy.
            </p>
          </div>
          
          <h4 className="text-xl font-bold text-[#26262c] mb-6">Event Gallery</h4>
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-4">
            {[...Array(15)].map((_, index) => (
              <div key={index} className="bg-gray-200 border-2 border-dashed rounded-lg w-full h-48 flex items-center justify-center">
                <span className="text-gray-500 text-xs">Gala Dinner 2023 {index + 1}</span>
              </div>
            ))}
          </div>
        </div>
      </section>

      <div className="border-t border-gray-200 mx-6 sm:mx-8 max-w-6xl"></div>

      {/* Event 5: Valentine's Day Picnic (Feb 2024) */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-6 sm:px-8 max-w-6xl">
          <h6 className="text-lg font-medium text-[#6e71e4] mb-2">February 14 / 2024 / 14:00pm</h6>
          <h3 className="text-2xl md:text-3xl font-bold text-[#2107c8] mb-8" style={{ textShadow: '1px 1px 2px rgba(0,0,0,0.1)' }}>
            Valentine's Day Picnic
          </h3>
          
          <div className="mb-8">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
              <div className="bg-gray-200 border-2 border-dashed rounded-xl w-full h-64 flex items-center justify-center">
                <span className="text-gray-500">IMG-20240215-WA0004</span>
              </div>
              <div className="bg-gray-200 border-2 border-dashed rounded-xl w-full h-64 flex items-center justify-center">
                <span className="text-gray-500">IMG-20240215-WA0005</span>
              </div>
            </div>
            
            <p className="text-[#76767f] mb-6">
              Our Valentine's Day Picnic remains a cherished tradition that fosters community spirit and celebrates the bonds between our students and staff. The event featured picnic baskets, games, talent shows, and dance competitions, creating lasting memories for all participants.
            </p>
          </div>
          
          <h4 className="text-xl font-bold text-[#26262c] mb-6">Event Gallery</h4>
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-4">
            {[...Array(15)].map((_, index) => (
              <div key={index} className="bg-gray-200 border-2 border-dashed rounded-lg w-full h-48 flex items-center justify-center">
                <span className="text-gray-500 text-xs">Valentine's Day Picnic {index + 1}</span>
              </div>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
};

export default EventsPage;