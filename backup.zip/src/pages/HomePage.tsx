import React from 'react';
import { Play, Users, Award, Target, BookOpen, Music, Dumbbell, Palette } from 'lucide-react';

const HomePage: React.FC = () => {
  return (
    <div className="relative">
      {/* Hero Section */}
      <section className="relative h-96 md:h-[500px] flex items-center">
        {/* Background image - replace src with your image path */}
        <div className="absolute inset-0 overflow-hidden">
          <img
        src="https://sacredheartoakford.co.za/wp-content/uploads/2024/05/20240523_163224-scaled.jpg"
        alt="Sacred Heart Secondary School"
        className="w-full h-full object-cover object-center"
        loading="lazy"
          />
          <div className="absolute inset-0 bg-gray-900/60"></div>
          <div className="absolute inset-0 bg-gradient-to-r from-black/40 via-transparent to-transparent"></div>
        </div>

        <div className="relative z-10 w-[80%] mx-auto">
          <div className="max-w-3xl">
        <h1 className="text-4xl md:text-5xl font-bold text-white mb-4">Sacred Heart Secondary School</h1>
        <div className="w-20 h-1 bg-[#4747d7] mb-6"></div>
        <p className="text-xl text-[#bfd1ff] mb-8">
          <span className="font-bold">Unlock your child's potential</span> with the world-class education at Sacred Heart Secondary School and Boarding Facility
        </p>
        <a
          href="/academics"
          className="bg-[#4747d7] hover:bg-[#3a3ac5] text-white font-medium py-2 px-6 rounded-md transition duration-300 inline-block"
        >
          Our Academics
        </a>
          </div>
        </div>
      </section>

      {/* Introduction Section */}
      <section className="py-16 bg-white">
        <div className="w-[80%] mx-auto">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-[#26262c] mb-4">Learning Begins With Us</h2>
            <div className="w-20 h-1 bg-[#4747d7] mx-auto"></div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 items-center">
            <div>
              <p className="text-[#76767f] mb-4">
                Our school's safe and supportive environment creates opportunities for each child to grow and learn through play-based exploration. We believe in the power of passion and dedication to learning.
              </p>
              <p className="text-[#76767f]">
                Our programs are designed to meet the needs of each individual child. We provide an environment that encourages children to become confident and capable learners.
              </p>
            </div>
            <div>
              <p className="text-[#76767f] mb-4">
                Sacred Heart Secondary School is an early learning academy with a passion for social-emotional development, literacy, numeracy, and other foundational skills.
              </p>
              <p className="text-[#76767f]">
                We focus on building a strong foundation for lifelong learning through our comprehensive curriculum and dedicated staff.
              </p>
            </div>
          </div>

          <div className="text-center mt-8">
            <a
              href="#"
              className="bg-[#4747d7] hover:bg-[#3a3ac5] text-white font-medium py-2 px-6 rounded-md transition duration-300"
            >
              Know More About Us
            </a>
          </div>
        </div>
      </section>

      {/* Statistics Strip */}
      <section className="py-12 bg-[#f6f6f6]">
        <div className="w-[80%] mx-auto">
          <h6 className="text-center text-lg font-semibold text-[#26262c] mb-8">Sacred Heart Secondary School at a Glance</h6>

          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-8">
            <div className="text-center">
              <div className="text-4xl font-bold text-[#4747d7]">500+</div>
              <p className="text-[#76767f]">Current Enrollments</p>
            </div>
            <div className="text-center">
              <div className="text-4xl font-bold text-[#4747d7]">27+</div>
              <p className="text-[#76767f]">Qualified Staff</p>
            </div>
            <div className="text-center">
              <div className="text-4xl font-bold text-[#4747d7]">12+</div>
              <p className="text-[#76767f]">Clubs & Activities</p>
            </div>
            <div className="text-center">
              <div className="text-4xl font-bold text-[#4747d7]">8+</div>
              <p className="text-[#76767f]">SGB Members</p>
            </div>
          </div>
        </div>
      </section>

      {/* Video Section */}
      <section className="py-16 bg-white">
        <div className="w-[80%] mx-auto">
          <div className="max-w-4xl mx-auto bg-gray-200 border-2 border-dashed rounded-xl w-full h-96 flex items-center justify-center">
            <div className="text-center">
              <Play className="w-16 h-16 text-gray-500 mx-auto" />
              <p className="mt-4 text-lg text-gray-600">School Introduction Video</p>
            </div>
          </div>
        </div>
      </section>

      {/* Principal's Address */}
      <section className="py-16 bg-[#f6f6f6]">
        <div className="w-[80%] mx-auto">
          <div className="max-w-4xl mx-auto text-center">
            <h2 className="text-4xl font-caveat font-bold text-[#948f79] mb-8">Principal's Address</h2>

            <div className="mb-8 flex justify-center">
              <div className="bg-gray-200 border-2 border-dashed rounded-xl w-64 h-64 flex items-center justify-center">
                <div className="text-center">
                  <div className="bg-gray-300 border-2 border-dashed rounded-full w-16 h-16 mx-auto mb-4"></div>
                  <p className="font-semibold text-[#26262c]">Mrs SP Hlongwa</p>
                  <p className="text-[#76767f]">Principal</p>
                </div>
              </div>
            </div>

            <div className="relative">
              <p className="text-[#76767f] italic text-xl mb-6">
                "Education is not the learning of fact, but the training of the mind to think" - Albert Einstein
              </p>
              <p className="text-[#76767f] mb-4">
                At Sacred Heart Secondary School, we believe in fostering lifelong learning and shaping leaders of tomorrow. Our dedicated faculty and comprehensive programs ensure that every student reaches their full potential.
              </p>
              <p className="text-[#76767f]">
                We aim at inspiring our students to dream more, learn more, do more, and become more in their respective journeys of life.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Curriculum Overview */}
      <section className="py-16 bg-white">
        <div className="w-[80%] mx-auto">
          <h2 className="text-3xl font-bold text-[#26262c] text-center mb-12">Curriculum Overview</h2>

          <p className="text-center text-[#76767f] mb-12 max-w-3xl mx-auto">
            Sacred Heart Secondary School offers a broad and balanced curriculum to meet the needs of each individual child. Our programs are designed to encourage children to become confident and capable learners.
          </p>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            <div className="bg-[#f6f7fd] rounded-lg overflow-hidden shadow-md">
              <div className="bg-gray-200 border-2 border-dashed w-full h-48 flex items-center justify-center">
                <BookOpen className="w-12 h-12 text-gray-400" />
              </div>
              <div className="p-6">
                <h3 className="text-xl font-semibold text-[#26262c] mb-2">Computer Application Technology</h3>
                <p className="text-[#76767f]">Developing digital literacy and technical skills for the modern world.</p>
              </div>
            </div>

            <div className="bg-[#f6f7fd] rounded-lg overflow-hidden shadow-md">
              <div className="bg-gray-200 border-2 border-dashed w-full h-48 flex items-center justify-center">
                <Target className="w-12 h-12 text-gray-400" />
              </div>
              <div className="p-6">
                <h3 className="text-xl font-semibold text-[#26262c] mb-2">Science</h3>
                <p className="text-[#76767f]">Exploring the natural world through hands-on experiments and discovery.</p>
              </div>
            </div>

            <div className="bg-[#f6f7fd] rounded-lg overflow-hidden shadow-md">
              <div className="bg-gray-200 border-2 border-dashed w-full h-48 flex items-center justify-center">
                <Award className="w-12 h-12 text-gray-400" />
              </div>
              <div className="p-6">
                <h3 className="text-xl font-semibold text-[#26262c] mb-2">Mathematics</h3>
                <p className="text-[#76767f]">Building logical thinking and problem-solving capabilities.</p>
              </div>
            </div>

            <div className="bg-[#f6f7fd] rounded-lg overflow-hidden shadow-md">
              <div className="bg-gray-200 border-2 border-dashed w-full h-48 flex items-center justify-center">
                <Users className="w-12 h-12 text-gray-400" />
              </div>
              <div className="p-6">
                <h3 className="text-xl font-semibold text-[#26262c] mb-2">Languages</h3>
                <p className="text-[#76767f]">Fostering communication skills and cultural understanding.</p>
              </div>
            </div>

            <div className="bg-[#f6f7fd] rounded-lg overflow-hidden shadow-md">
              <div className="bg-gray-200 border-2 border-dashed w-full h-48 flex items-center justify-center">
                <BookOpen className="w-12 h-12 text-gray-400" />
              </div>
              <div className="p-6">
                <h3 className="text-xl font-semibold text-[#26262c] mb-2">Humanities</h3>
                <p className="text-[#76767f]">Understanding history, geography, and social studies.</p>
              </div>
            </div>

            <div className="bg-[#f6f7fd] rounded-lg overflow-hidden shadow-md">
              <div className="bg-gray-200 border-2 border-dashed w-full h-48 flex items-center justify-center">
                <Palette className="w-12 h-12 text-gray-400" />
              </div>
              <div className="p-6">
                <h3 className="text-xl font-semibold text-[#26262c] mb-2">Creative Art</h3>
                <p className="text-[#76767f]">Encouraging creativity and self-expression through visual arts.</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Co-curricular Activities */}
      <section className="py-16 bg-[#f6f7fd]">
        <div className="w-[80%] mx-auto">
          <h2 className="text-3xl font-bold text-[#26262c] text-center mb-12">Our Co-curricular Activities</h2>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div>
              <div className="bg-gray-200 border-2 border-dashed rounded-xl w-full h-96 flex items-center justify-center">
                <div className="text-center">
                  <Target className="w-12 h-12 text-gray-400 mx-auto mb-4" />
                  <p className="text-gray-600">Activities Gallery</p>
                </div>
              </div>
            </div>

            <div className="space-y-8">
              <div className="flex">
                <div className="mr-4 mt-1">
                  <Dumbbell className="w-6 h-6 text-[#4747d7]" />
                </div>
                <div>
                  <h3 className="text-xl font-semibold text-[#26262c] mb-2">Athletics</h3>
                  <p className="text-[#76767f]">Our students are passionate about sports and participate in various athletic competitions throughout the year.</p>
                </div>
              </div>

              <div className="flex">
                <div className="mr-4 mt-1">
                  <Music className="w-6 h-6 text-[#4747d7]" />
                </div>
                <div>
                  <h3 className="text-xl font-semibold text-[#26262c] mb-2">Performing Arts & Music</h3>
                  <p className="text-[#76767f]">With professionals on board, we offer comprehensive music and performing arts programs.</p>
                </div>
              </div>

              <div className="flex">
                <div className="mr-4 mt-1">
                  <Target className="w-6 h-6 text-[#4747d7]" />
                </div>
                <div>
                  <h3 className="text-xl font-semibold text-[#26262c] mb-2">Swimming (coming soon)</h3>
                  <p className="text-[#76767f]">We soon gonna have a swimming sport.</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Newsletter Subscription */}
      <section className="py-16 bg-[#4747d7]">
        <div className="w-[80%] mx-auto text-center">
          <h2 className="text-2xl font-bold text-white mb-4">Wish to know more about admissions and updates? Subscribe now!</h2>
          <p className="text-[#bfd1ff] mb-8">Join our newsletter to stay informed about school events and important announcements.</p>

          <div className="max-w-md mx-auto flex">
            <input
              type="email"
              placeholder="Enter your email"
              className="flex-grow px-4 py-2 rounded-l-md focus:outline-none"
            />
            <button className="bg-[#26262c] text-white px-6 py-2 rounded-r-md hover:bg-[#3a3ac5] transition duration-300">
              Subscribe
            </button>
          </div>
        </div>
      </section>
    </div>
  );
};

export default HomePage;