/** @type {import('tailwindcss').Config} */
export default {
  content: [
    "./index.html",
    "./src/**/*.{js,ts,jsx,tsx}",
  ],
  theme: {
    extend: {
      colors: {
        primary: '#4747d7',
        secondary: '#26262c',
        text: '#76767f',
        lightbg: '#f6f7fd',
        accent: '#bfd1ff',
      }
    },
  },
  plugins: [],
}